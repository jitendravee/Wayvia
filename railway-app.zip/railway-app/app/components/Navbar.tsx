import Link from "next/link";

const LINKS = [
  { href: "/running-status", label: "Running Status" },
  { href: "/pnr-status", label: "PNR Status" },
];

export default function Navbar() {
  return (
    <header className="sticky top-0 z-30 border-b border-border bg-white/85 backdrop-blur">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-3.5 sm:px-6">
        <Link href="/" className="flex items-center gap-2">
          <img src="/logo.png" alt="Wayvia" className="h-12 w-12 rounded-lg object-contain" />
          <span className="font-display text-lg font-semibold mt-2 text-ink">Wayvia</span>
        </Link>

        <nav className="hidden items-center gap-6 sm:flex">
          {LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className="text-[13.5px] font-medium text-ink-muted transition-colors hover:text-violet"
            >
              {l.label}
            </Link>
          ))}
        </nav>

        <Link
          href="/pnr-status"
          className="rounded-full bg-violet px-4 py-2 font-display text-[13px] font-semibold text-white! shadow-sm shadow-violet-soft transition-colors hover:bg-violet-dark"
        >
          Check PNR
        </Link>
      </div>
    </header>
  );
}
